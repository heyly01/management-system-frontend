import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files
app.use(express.static(__dirname));

// Serve main HTML files
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/booking", (req, res) => {
  res.sendFile(path.join(__dirname, "booking.html"));
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "admin.html"));
});

// API routes for services
app.get("/api/services", (req, res) => {
  // Mock service data from our frontend
  const serviceCategories = [
    {
      category: "Haircut & Styling",
      services: [
        {
          id: 1,
          name: "Women's Haircut",
          description:
            "Professional haircut service including consultation, shampoo, and style.",
          duration: 60,
          price: 600,
        },
        {
          id: 2,
          name: "Men's Haircut",
          description:
            "Precision haircut service for men including consultation and styling.",
          duration: 45,
          price: 450,
        },
        {
          id: 3,
          name: "Kids Haircut",
          description:
            "Gentle and fun haircut experience for children under 12.",
          duration: 30,
          price: 300,
        },
        {
          id: 4,
          name: "Blowout & Styling",
          description:
            "Professional blow dry and styling service for any occasion.",
          duration: 45,
          price: 500,
        },
      ],
    },
    {
      category: "Hair Coloring",
      services: [
        {
          id: 5,
          name: "Root Touch-up",
          description:
            "Color application to the roots to cover grey or regrowth.",
          duration: 60,
          price: 1200,
        },
        {
          id: 6,
          name: "Full Color",
          description:
            "All-over hair color application for a complete color change or refresh.",
          duration: 90,
          price: 2000,
        },
        {
          id: 7,
          name: "Highlights/Lowlights",
          description:
            "Dimensional color technique to add depth and dimension to hair.",
          duration: 120,
          price: 2500,
        },
        {
          id: 8,
          name: "Balayage/Ombre",
          description:
            "Hand-painted highlighting technique for a natural, sun-kissed look.",
          duration: 180,
          price: 3500,
        },
      ],
    },
    {
      category: "Hair Treatments",
      services: [
        {
          id: 9,
          name: "Deep Conditioning Treatment",
          description:
            "Intensive conditioning to restore moisture and shine to dry, damaged hair.",
          duration: 30,
          price: 800,
        },
        {
          id: 10,
          name: "Scalp Treatment",
          description:
            "Therapeutic treatment to address scalp issues and promote healthy hair growth.",
          duration: 45,
          price: 1000,
        },
        {
          id: 11,
          name: "Keratin Smoothing Treatment",
          description:
            "Smoothing treatment to reduce frizz and add shine for up to 3 months.",
          duration: 120,
          price: 4500,
        },
        {
          id: 12,
          name: "Hair Spa",
          description:
            "Luxurious spa treatment for hair including massage and steam therapy.",
          duration: 60,
          price: 1500,
        },
      ],
    },
    {
      category: "Beauty Services",
      services: [
        {
          id: 13,
          name: "Eyebrow Threading",
          description: "Precise eyebrow shaping using the threading technique.",
          duration: 15,
          price: 150,
        },
        {
          id: 14,
          name: "Facial",
          description:
            "Customized facial treatment to cleanse, exfoliate, and nourish the skin.",
          duration: 60,
          price: 1800,
        },
        {
          id: 15,
          name: "Manicure",
          description:
            "Classic manicure service including nail shaping, cuticle care, and polish.",
          duration: 45,
          price: 500,
        },
        {
          id: 16,
          name: "Pedicure",
          description:
            "Relaxing pedicure service including foot soak, exfoliation, and polish.",
          duration: 60,
          price: 700,
        },
      ],
    },
  ];

  res.json(serviceCategories);
});

// API route for staff
app.get("/api/staff", (req, res) => {
  // Mock staff data
  const staffMembers = [
    {
      id: 1,
      name: "Priya Sharma",
      role: "Senior Hair Stylist",
      image: "",
      bio: "With over 8 years of experience, Priya specializes in precision cuts and creative coloring techniques.",
      specialties: ["Precision Cuts", "Creative Color", "Balayage"],
      experience: 8,
    },
    {
      id: 2,
      name: "Raj Patel",
      role: "Master Stylist",
      image: "",
      bio: "Raj is our master stylist with 12 years of experience and international training in the latest hair trends.",
      specialties: ["Avant-garde Styling", "Color Correction", "Extensions"],
      experience: 12,
    },
    {
      id: 3,
      name: "Ananya Singh",
      role: "Color Specialist",
      image: "",
      bio: "Ananya is our color expert with advanced training in the latest techniques to achieve the perfect shade for every client.",
      specialties: ["Balayage", "Fashion Colors", "Highlighting"],
      experience: 6,
    },
    {
      id: 4,
      name: "Vikram Malhotra",
      role: "Stylist & Barber",
      image: "",
      bio: "Specializing in both men's and women's styles, Vikram is known for his versatility and attention to detail.",
      specialties: ["Men's Cuts", "Beard Grooming", "Classic Styling"],
      experience: 5,
    },
    {
      id: 5,
      name: "Neha Verma",
      role: "Beauty Therapist",
      image: "",
      bio: "Neha is our beauty expert providing exceptional skincare and makeup services for all occasions.",
      specialties: ["Facials", "Makeup", "Threading"],
      experience: 7,
    },
    {
      id: 6,
      name: "Arjun Kapoor",
      role: "Junior Stylist",
      image: "",
      bio: "With fresh ideas and techniques, Arjun brings a modern perspective to our salon team.",
      specialties: ["Modern Cuts", "Styling", "Client Consultation"],
      experience: 2,
    },
  ];

  res.json(staffMembers);
});

// Start the server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on port ${PORT}`);
});
