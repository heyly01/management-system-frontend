// Admin Dashboard JavaScript for Jawed Habib Hair & Beauty

// Mock data for the admin dashboard
// In a real application, this data would be fetched from a server

// Appointments data
const appointmentsData = [
  {
    id: 1,
    date: "2025-03-31",
    time: "10:00",
    customerId: 1,
    customerName: "Meera Patel",
    customerPhone: "9876543210",
    serviceId: 1,
    serviceName: "Women's Haircut",
    staffId: 1,
    staffName: "Priya Sharma",
    status: "confirmed",
    price: 600,
    notes: "First-time customer",
  },
  {
    id: 2,
    date: "2025-03-31",
    time: "11:30",
    customerId: 2,
    customerName: "Rahul Singh",
    customerPhone: "8765432109",
    serviceId: 2,
    serviceName: "Men's Haircut",
    staffId: 4,
    staffName: "Vikram Malhotra",
    status: "confirmed",
    price: 450,
    notes: "",
  },
  {
    id: 3,
    date: "2025-03-31",
    time: "14:00",
    customerId: 3,
    customerName: "Anjali Desai",
    customerPhone: "7654321098",
    serviceId: 7,
    serviceName: "Highlights/Lowlights",
    staffId: 3,
    staffName: "Ananya Singh",
    status: "confirmed",
    price: 2500,
    notes: "Prefers cooler tones",
  },
  {
    id: 4,
    date: "2025-04-01",
    time: "10:30",
    customerId: 4,
    customerName: "Karan Mehta",
    customerPhone: "6543210987",
    serviceId: 2,
    serviceName: "Men's Haircut",
    staffId: 2,
    staffName: "Raj Patel",
    status: "pending",
    price: 450,
    notes: "",
  },
  {
    id: 5,
    date: "2025-04-01",
    time: "16:00",
    customerId: 5,
    customerName: "Pooja Shah",
    customerPhone: "9876543211",
    serviceId: 6,
    serviceName: "Full Color",
    staffId: 3,
    staffName: "Ananya Singh",
    status: "confirmed",
    price: 2000,
    notes: "Allergic to certain dyes, check notes in customer profile",
  },
  {
    id: 6,
    date: "2025-04-02",
    time: "13:30",
    customerId: 6,
    customerName: "Arjun Kapoor",
    customerPhone: "8765432100",
    serviceId: 12,
    serviceName: "Hair Spa",
    staffId: 1,
    staffName: "Priya Sharma",
    status: "confirmed",
    price: 1500,
    notes: "",
  },
  {
    id: 7,
    date: "2025-04-02",
    time: "15:30",
    customerId: 7,
    customerName: "Riya Joshi",
    customerPhone: "7654321099",
    serviceId: 14,
    serviceName: "Facial",
    staffId: 5,
    staffName: "Neha Verma",
    status: "pending",
    price: 1800,
    notes: "Sensitive skin",
  },
  {
    id: 8,
    date: "2025-03-30",
    time: "12:00",
    customerId: 8,
    customerName: "Surya Kumar",
    customerPhone: "9988776655",
    serviceId: 2,
    serviceName: "Men's Haircut",
    staffId: 4,
    staffName: "Vikram Malhotra",
    status: "completed",
    price: 450,
    notes: "",
  },
  {
    id: 9,
    date: "2025-03-30",
    time: "14:00",
    customerId: 9,
    customerName: "Neha Shah",
    customerPhone: "8877665544",
    serviceId: 4,
    serviceName: "Blowout & Styling",
    staffId: 6,
    staffName: "Arjun Kapoor",
    status: "completed",
    price: 500,
    notes: "For a wedding function",
  },
  {
    id: 10,
    date: "2025-03-29",
    time: "11:00",
    customerId: 10,
    customerName: "Aditya Memon",
    customerPhone: "7766554433",
    serviceId: 8,
    serviceName: "Balayage/Ombre",
    staffId: 3,
    staffName: "Ananya Singh",
    status: "cancelled",
    price: 3500,
    notes: "Had an emergency",
  },
];

// Customers data
const customersData = [
  {
    id: 1,
    name: "Meera Patel",
    phone: "9876543210",
    email: "meera.p@example.com",
    gender: "female",
    lastVisit: "2025-03-31",
    totalVisits: 5,
    totalSpent: 5800,
    notes: "Prefers minimal styling products",
  },
  {
    id: 2,
    name: "Rahul Singh",
    phone: "8765432109",
    email: "rahul.s@example.com",
    gender: "male",
    lastVisit: "2025-03-31",
    totalVisits: 8,
    totalSpent: 4200,
    notes: "Regular customer, likes classic styles",
  },
  {
    id: 3,
    name: "Anjali Desai",
    phone: "7654321098",
    email: "anjali.d@example.com",
    gender: "female",
    lastVisit: "2025-03-31",
    totalVisits: 3,
    totalSpent: 7500,
    notes: "Loves experimenting with new colors",
  },
  {
    id: 4,
    name: "Karan Mehta",
    phone: "6543210987",
    email: "karan.m@example.com",
    gender: "male",
    lastVisit: "2025-04-01",
    totalVisits: 2,
    totalSpent: 900,
    notes: "",
  },
  {
    id: 5,
    name: "Pooja Shah",
    phone: "9876543211",
    email: "pooja.s@example.com",
    gender: "female",
    lastVisit: "2025-04-01",
    totalVisits: 6,
    totalSpent: 12000,
    notes: "Allergic to certain hair dyes, check before coloring",
  },
  {
    id: 6,
    name: "Arjun Kapoor",
    phone: "8765432100",
    email: "arjun.k@example.com",
    gender: "male",
    lastVisit: "2025-04-02",
    totalVisits: 1,
    totalSpent: 1500,
    notes: "New customer, referred by Meera Patel",
  },
  {
    id: 7,
    name: "Riya Joshi",
    phone: "7654321099",
    email: "riya.j@example.com",
    gender: "female",
    lastVisit: "2025-04-02",
    totalVisits: 4,
    totalSpent: 8200,
    notes: "Sensitive skin, use gentle products",
  },
  {
    id: 8,
    name: "Surya Kumar",
    phone: "9988776655",
    email: "surya.k@example.com",
    gender: "male",
    lastVisit: "2025-03-30",
    totalVisits: 10,
    totalSpent: 5500,
    notes: "Monthly haircut appointment",
  },
  {
    id: 9,
    name: "Neha Shah",
    phone: "8877665544",
    email: "neha.s@example.com",
    gender: "female",
    lastVisit: "2025-03-30",
    totalVisits: 3,
    totalSpent: 4800,
    notes: "",
  },
  {
    id: 10,
    name: "Aditya Memon",
    phone: "7766554433",
    email: "aditya.m@example.com",
    gender: "male",
    lastVisit: "2025-03-29",
    totalVisits: 2,
    totalSpent: 3500,
    notes: "Recently moved to the area",
  },
];

// Inventory data
const inventoryData = [
  {
    id: 1,
    name: "Professional Hair Dryer",
    category: "equipment",
    brand: "Dyson",
    supplier: "Beauty Equipment Ltd",
    costPrice: 15000,
    sellingPrice: 18000,
    stock: 3,
    minStock: 2,
    status: "in-stock",
  },
  {
    id: 2,
    name: "Hair Color - Medium Brown",
    category: "hair-care",
    brand: "L'Oreal",
    supplier: "L'Oreal India",
    costPrice: 350,
    sellingPrice: 600,
    stock: 15,
    minStock: 5,
    status: "in-stock",
  },
  {
    id: 3,
    name: "Hair Color - Blonde",
    category: "hair-care",
    brand: "L'Oreal",
    supplier: "L'Oreal India",
    costPrice: 350,
    sellingPrice: 600,
    stock: 3,
    minStock: 5,
    status: "low-stock",
  },
  {
    id: 4,
    name: "Straightening Iron",
    category: "equipment",
    brand: "Philips",
    supplier: "Beauty Equipment Ltd",
    costPrice: 2500,
    sellingPrice: 3500,
    stock: 4,
    minStock: 2,
    status: "in-stock",
  },
  {
    id: 5,
    name: "Shampoo - Damage Repair",
    category: "hair-care",
    brand: "Wella",
    supplier: "Salon Supplies Inc",
    costPrice: 400,
    sellingPrice: 800,
    stock: 8,
    minStock: 4,
    status: "in-stock",
  },
  {
    id: 6,
    name: "Conditioner - Damage Repair",
    category: "hair-care",
    brand: "Wella",
    supplier: "Salon Supplies Inc",
    costPrice: 400,
    sellingPrice: 800,
    stock: 6,
    minStock: 4,
    status: "in-stock",
  },
  {
    id: 7,
    name: "Facial Cleanser",
    category: "skin-care",
    brand: "Kiehl's",
    supplier: "Beauty Essentials",
    costPrice: 600,
    sellingPrice: 1200,
    stock: 2,
    minStock: 3,
    status: "low-stock",
  },
  {
    id: 8,
    name: "Hair Serum",
    category: "hair-care",
    brand: "Moroccan Oil",
    supplier: "Salon Supplies Inc",
    costPrice: 800,
    sellingPrice: 1500,
    stock: 0,
    minStock: 2,
    status: "out-of-stock",
  },
  {
    id: 9,
    name: "Styling Brush Set",
    category: "accessories",
    brand: "Vega",
    supplier: "Beauty Essentials",
    costPrice: 1200,
    sellingPrice: 2000,
    stock: 5,
    minStock: 3,
    status: "in-stock",
  },
  {
    id: 10,
    name: "Hair Mask - Intensive Repair",
    category: "hair-care",
    brand: "Kerastase",
    supplier: "Salon Supplies Inc",
    costPrice: 900,
    sellingPrice: 1800,
    stock: 7,
    minStock: 3,
    status: "in-stock",
  },
];

// Recent activities
const recentActivities = [
  {
    id: 1,
    type: "appointment",
    action: "booked",
    details: "Meera Patel booked a Women's Haircut appointment",
    timestamp: "2025-03-31T09:15:00",
    icon: "calendar-plus",
  },
  {
    id: 2,
    type: "appointment",
    action: "completed",
    details: "Surya Kumar's Men's Haircut appointment was completed",
    timestamp: "2025-03-30T13:00:00",
    icon: "calendar-check",
  },
  {
    id: 3,
    type: "inventory",
    action: "low",
    details: "Hair Color - Blonde is running low on stock (3 remaining)",
    timestamp: "2025-03-30T15:30:00",
    icon: "exclamation-triangle",
  },
  {
    id: 4,
    type: "appointment",
    action: "cancelled",
    details: "Aditya Memon cancelled the Balayage/Ombre appointment",
    timestamp: "2025-03-29T09:45:00",
    icon: "calendar-times",
  },
  {
    id: 5,
    type: "customer",
    action: "new",
    details: "Arjun Kapoor registered as a new customer",
    timestamp: "2025-03-28T11:20:00",
    icon: "user-plus",
  },
  {
    id: 6,
    type: "inventory",
    action: "out",
    details: "Hair Serum is out of stock",
    timestamp: "2025-03-28T10:15:00",
    icon: "box",
  },
];

// ===== DOM Ready =====
$(document).ready(function () {
  // Initialize Dashboard
  initializeDashboard();

  // Initialize Appointments Tab
  initializeAppointmentsTab();

  // Initialize Services Tab
  initializeServicesTab();

  // Initialize Staff Tab
  initializeStaffTab();

  // Initialize Customers Tab
  initializeCustomersTab();

  // Initialize Inventory Tab
  initializeInventoryTab();

  // Setup Form Submissions
  setupFormSubmissions();
});

// ===== Functions =====

// Initialize Dashboard
function initializeDashboard() {
  // Update dashboard statistics
  updateDashboardStatistics();

  // Load upcoming appointments
  loadUpcomingAppointments();

  // Load popular services chart
  loadPopularServicesChart();

  // Load recent activities
  loadRecentActivities();

  // Load inventory status
  loadInventoryStatus();
}

// Update Dashboard Statistics
function updateDashboardStatistics() {
  // Count today's appointments
  const today = "2025-03-31"; // Fixed date for demonstration
  const todayAppointments = appointmentsData.filter(
    (appointment) => appointment.date === today
  );
  $("#today-appointments-count").text(todayAppointments.length);

  // Count new bookings in the last 7 days
  const newBookings = appointmentsData.filter((appointment) => {
    // In a real application, you would compare dates properly
    // For now, let's assume all appointments in our data are within the last 7 days
    return (
      appointment.status === "confirmed" || appointment.status === "pending"
    );
  });
  $("#new-bookings-count").text(newBookings.length);

  // Count total customers
  $("#total-customers").text(customersData.length);

  // Calculate monthly revenue
  const monthlyRevenue = appointmentsData
    .filter((appointment) => appointment.status === "completed")
    .reduce((sum, appointment) => sum + appointment.price, 0);
  $("#monthly-revenue").text(`₹${monthlyRevenue}`);
}

// Load Upcoming Appointments
function loadUpcomingAppointments() {
  const upcomingAppointmentsContainer = $("#upcoming-appointments-table");

  if (upcomingAppointmentsContainer.length) {
    // Sort appointments by date and time
    const sortedAppointments = [...appointmentsData]
      .filter(
        (appointment) =>
          appointment.status === "confirmed" || appointment.status === "pending"
      )
      .sort((a, b) => {
        if (a.date !== b.date) {
          return a.date.localeCompare(b.date);
        }
        return a.time.localeCompare(b.time);
      })
      .slice(0, 5); // Show only the next 5 appointments

    if (sortedAppointments.length === 0) {
      upcomingAppointmentsContainer.html(
        '<tr><td colspan="5" class="text-center">No upcoming appointments</td></tr>'
      );
      return;
    }

    let appointmentsHtml = "";
    sortedAppointments.forEach((appointment) => {
      const statusClass = getStatusClass(appointment.status);

      appointmentsHtml += `
        <tr>
          <td>${formatDate(appointment.date)} ${appointment.time}</td>
          <td>${appointment.customerName}</td>
          <td>${appointment.serviceName}</td>
          <td>${appointment.staffName}</td>
          <td><span class="status-badge ${statusClass}">${capitalizeFirstLetter(
        appointment.status
      )}</span></td>
        </tr>
      `;
    });

    upcomingAppointmentsContainer.html(appointmentsHtml);
  }
}

// Load Popular Services Chart
function loadPopularServicesChart() {
  const popularServicesContainer = $("#popular-services-chart");

  if (popularServicesContainer.length) {
    // In a real application, you would calculate this from appointment data
    // For this example, we'll use fixed data

    // Group appointments by service and count them
    const serviceCountMap = {};
    appointmentsData.forEach((appointment) => {
      if (!serviceCountMap[appointment.serviceName]) {
        serviceCountMap[appointment.serviceName] = 0;
      }
      serviceCountMap[appointment.serviceName]++;
    });

    // Convert to array and sort by count
    const serviceData = Object.entries(serviceCountMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5); // Top 5 services

    // Generate HTML
    let chartHtml = "";

    serviceData.forEach((service) => {
      const percentage = (service.count / appointmentsData.length) * 100;

      chartHtml += `
        <div class="service-stat mb-3">
          <div class="d-flex justify-content-between mb-1">
            <span>${service.name}</span>
            <span>${service.count} bookings</span>
          </div>
          <div class="progress" style="height: 8px;">
            <div class="progress-bar bg-primary" role="progressbar" style="width: ${percentage}%" aria-valuenow="${percentage}" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>
      `;
    });

    popularServicesContainer.html(chartHtml);
  }
}

// Load Recent Activities
function loadRecentActivities() {
  const recentActivitiesContainer = $("#recent-activities");

  if (recentActivitiesContainer.length) {
    let activitiesHtml = "";

    recentActivities.slice(0, 5).forEach((activity) => {
      const activityTime = new Date(activity.timestamp);
      const timeString = activityTime.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
      });
      const dateString = activityTime.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });

      let iconBgClass = "bg-info bg-opacity-10 text-info";
      switch (activity.type) {
        case "appointment":
          if (activity.action === "booked") {
            iconBgClass = "bg-success bg-opacity-10 text-success";
          } else if (activity.action === "cancelled") {
            iconBgClass = "bg-danger bg-opacity-10 text-danger";
          } else {
            iconBgClass = "bg-primary bg-opacity-10 text-primary";
          }
          break;
        case "inventory":
          iconBgClass = "bg-warning bg-opacity-10 text-warning";
          break;
        case "customer":
          iconBgClass = "bg-info bg-opacity-10 text-info";
          break;
      }

      activitiesHtml += `
        <div class="activity-item d-flex">
          <div class="activity-icon rounded-circle ${iconBgClass}">
            <i class="fas fa-${activity.icon}"></i>
          </div>
          <div>
            <p class="mb-1">${activity.details}</p>
            <small class="activity-time">${dateString} at ${timeString}</small>
          </div>
        </div>
      `;
    });

    recentActivitiesContainer.html(activitiesHtml);
  }
}

// Load Inventory Status
function loadInventoryStatus() {
  const inventoryStatusContainer = $("#inventory-status");

  if (inventoryStatusContainer.length) {
    // Filter low or out of stock items
    const lowStockItems = inventoryData
      .filter(
        (item) => item.status === "low-stock" || item.status === "out-of-stock"
      )
      .slice(0, 5);

    if (lowStockItems.length === 0) {
      inventoryStatusContainer.html(
        '<p class="text-center">All inventory items are well-stocked.</p>'
      );
      return;
    }

    let inventoryHtml = "";

    lowStockItems.forEach((item) => {
      const stockPercentage = Math.min(100, (item.stock / item.minStock) * 100);
      let stockClass = "stock-normal";

      if (item.stock === 0) {
        stockClass = "stock-critical";
      } else if (item.stock < item.minStock) {
        stockClass = "stock-low";
      }

      inventoryHtml += `
        <div class="inventory-item">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <div>
              <span class="fw-medium">${item.name}</span>
              <small class="d-block text-muted">${item.brand}</small>
            </div>
            <span class="stock-count fw-semibold">${item.stock}/${item.minStock}</span>
          </div>
          <div class="stock-level">
            <div class="stock-fill ${stockClass}" style="width: ${stockPercentage}%"></div>
          </div>
        </div>
      `;
    });

    inventoryStatusContainer.html(inventoryHtml);
  }
}

// Initialize Appointments Tab
function initializeAppointmentsTab() {
  const appointmentsTableContainer = $("#appointments-table");

  if (appointmentsTableContainer.length) {
    renderAppointmentsTable(appointmentsData);

    // Handle filters
    $(
      "#appointment-date-filter, #appointment-staff-filter, #appointment-status-filter"
    ).on("change", function () {
      filterAppointments();
    });

    // Handle search
    $("#appointment-search").on("input", function () {
      filterAppointments();
    });

    // Update counts
    updateAppointmentCounts();
  }
}

// Render Appointments Table
function renderAppointmentsTable(appointments) {
  const appointmentsTableContainer = $("#appointments-table");

  if (appointmentsTableContainer.length && appointments.length > 0) {
    let appointmentsHtml = "";

    appointments.forEach((appointment) => {
      const statusClass = getStatusClass(appointment.status);

      appointmentsHtml += `
        <tr data-id="${appointment.id}">
          <td>${formatDate(appointment.date)} ${appointment.time}</td>
          <td>
            <div>
              <span class="fw-medium">${appointment.customerName}</span>
              <small class="d-block text-muted">${
                appointment.customerPhone
              }</small>
            </div>
          </td>
          <td>${appointment.serviceName}</td>
          <td>${appointment.staffName}</td>
          <td><span class="status-badge ${statusClass}">${capitalizeFirstLetter(
        appointment.status
      )}</span></td>
          <td>₹${appointment.price}</td>
          <td>
            <div class="btn-group">
              <button class="btn btn-sm btn-outline-primary edit-appointment" data-id="${
                appointment.id
              }">
                <i class="fas fa-edit"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger delete-appointment" data-id="${
                appointment.id
              }">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    });

    appointmentsTableContainer.html(appointmentsHtml);

    // Setup edit and delete buttons
    $(".edit-appointment").on("click", function () {
      const appointmentId = $(this).data("id");
      // In a real application, you would open a modal with the appointment details
      alert(`Edit appointment ${appointmentId}`);
    });

    $(".delete-appointment").on("click", function () {
      const appointmentId = $(this).data("id");
      // In a real application, you would show a confirmation modal
      alert(`Delete appointment ${appointmentId}`);
    });
  } else {
    appointmentsTableContainer.html(
      '<tr><td colspan="7" class="text-center">No appointments found</td></tr>'
    );
  }
}

// Filter Appointments
function filterAppointments() {
  const dateFilter = $("#appointment-date-filter").val();
  const staffFilter = $("#appointment-staff-filter").val();
  const statusFilter = $("#appointment-status-filter").val();
  const searchTerm = $("#appointment-search").val().toLowerCase();

  let filteredAppointments = [...appointmentsData];

  // Apply date filter
  if (dateFilter) {
    switch (dateFilter) {
      case "today":
        filteredAppointments = filteredAppointments.filter(
          (appointment) => appointment.date === "2025-03-31"
        );
        break;
      case "tomorrow":
        filteredAppointments = filteredAppointments.filter(
          (appointment) => appointment.date === "2025-04-01"
        );
        break;
      case "this-week":
        // In a real application, you would filter by the current week
        // For this example, we'll include all dates in our dataset
        break;
      case "this-month":
        // In a real application, you would filter by the current month
        // For this example, we'll include all dates in our dataset
        break;
    }
  }

  // Apply staff filter
  if (staffFilter) {
    filteredAppointments = filteredAppointments.filter(
      (appointment) => appointment.staffId.toString() === staffFilter
    );
  }

  // Apply status filter
  if (statusFilter) {
    filteredAppointments = filteredAppointments.filter(
      (appointment) => appointment.status === statusFilter
    );
  }

  // Apply search
  if (searchTerm) {
    filteredAppointments = filteredAppointments.filter(
      (appointment) =>
        appointment.customerName.toLowerCase().includes(searchTerm) ||
        appointment.serviceName.toLowerCase().includes(searchTerm)
    );
  }

  // Sort appointments by date and time
  filteredAppointments.sort((a, b) => {
    if (a.date !== b.date) {
      return a.date.localeCompare(b.date);
    }
    return a.time.localeCompare(b.time);
  });

  // Render filtered appointments
  renderAppointmentsTable(filteredAppointments);

  // Update counts
  updateAppointmentCounts(filteredAppointments.length);
}

// Update Appointment Counts
function updateAppointmentCounts(filteredCount) {
  const totalCount = appointmentsData.length;
  $("#total-appointments").text(totalCount);
  $("#shown-appointments").text(
    filteredCount !== undefined ? filteredCount : totalCount
  );
}

// Initialize Services Tab
function initializeServicesTab() {
  const servicesTableContainer = $("#services-table");

  if (servicesTableContainer.length) {
    // In a real application, you would fetch services from the server
    // For this example, we'll use the service data from our serviceCategories array

    let allServices = [];
    serviceCategories.forEach((category) => {
      category.services.forEach((service) => {
        allServices.push({
          ...service,
          category: category.category,
          status: "active", // Assume all services are active for this example
        });
      });
    });

    renderServicesTable(allServices);

    // Populate category filter
    const categoryFilter = $("#service-category-filter");
    const uniqueCategories = [
      ...new Set(serviceCategories.map((category) => category.category)),
    ];

    uniqueCategories.forEach((category) => {
      categoryFilter.append(`<option value="${category}">${category}</option>`);
    });

    // Handle filters and search
    $("#service-category-filter, #service-status-filter").on(
      "change",
      function () {
        filterServices(allServices);
      }
    );

    $("#service-search").on("input", function () {
      filterServices(allServices);
    });
  }
}

// Render Services Table
function renderServicesTable(services) {
  const servicesTableContainer = $("#services-table");

  if (servicesTableContainer.length && services.length > 0) {
    let servicesHtml = "";

    services.forEach((service) => {
      const statusClass =
        service.status === "active" ? "status-confirmed" : "status-cancelled";

      servicesHtml += `
        <tr data-id="${service.id}">
          <td>
            <div>
              <span class="fw-medium">${service.name}</span>
              <small class="d-block text-muted">${service.description.substring(
                0,
                50
              )}${service.description.length > 50 ? "..." : ""}</small>
            </div>
          </td>
          <td>${service.category}</td>
          <td>${service.duration} min</td>
          <td>₹${service.price}</td>
          <td><span class="status-badge ${statusClass}">${capitalizeFirstLetter(
        service.status
      )}</span></td>
          <td>
            <div class="btn-group">
              <button class="btn btn-sm btn-outline-primary edit-service" data-id="${
                service.id
              }">
                <i class="fas fa-edit"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger delete-service" data-id="${
                service.id
              }">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    });

    servicesTableContainer.html(servicesHtml);

    // Setup edit and delete buttons
    $(".edit-service").on("click", function () {
      const serviceId = $(this).data("id");
      // In a real application, you would open a modal with the service details
      alert(`Edit service ${serviceId}`);
    });

    $(".delete-service").on("click", function () {
      const serviceId = $(this).data("id");
      // In a real application, you would show a confirmation modal
      alert(`Delete service ${serviceId}`);
    });
  } else {
    servicesTableContainer.html(
      '<tr><td colspan="6" class="text-center">No services found</td></tr>'
    );
  }
}

// Filter Services
function filterServices(allServices) {
  const categoryFilter = $("#service-category-filter").val();
  const statusFilter = $("#service-status-filter").val();
  const searchTerm = $("#service-search").val().toLowerCase();

  let filteredServices = [...allServices];

  // Apply category filter
  if (categoryFilter) {
    filteredServices = filteredServices.filter(
      (service) => service.category === categoryFilter
    );
  }

  // Apply status filter
  if (statusFilter) {
    filteredServices = filteredServices.filter(
      (service) => service.status === statusFilter
    );
  }

  // Apply search
  if (searchTerm) {
    filteredServices = filteredServices.filter(
      (service) =>
        service.name.toLowerCase().includes(searchTerm) ||
        service.description.toLowerCase().includes(searchTerm)
    );
  }

  // Render filtered services
  renderServicesTable(filteredServices);
}

// Initialize Staff Tab
function initializeStaffTab() {
  const staffCardsContainer = $("#staff-cards");

  if (staffCardsContainer.length) {
    let staffCardsHtml = "";

    staffMembers.forEach((staff) => {
      staffCardsHtml += `
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body text-center p-4">
              <img src="${staff.image}" alt="${
        staff.name
      }" class="admin-staff-image mb-3">
              <h3 class="fs-5 fw-semibold mb-1">${staff.name}</h3>
              <p class="staff-role mb-3">${staff.role}</p>
              <p class="text-muted mb-3">${staff.bio}</p>
              <div class="mb-3">
                <div class="d-flex justify-content-between mb-2">
                  <span>Specialties:</span>
                  <span>${staff.specialties.join(", ")}</span>
                </div>
                <div class="d-flex justify-content-between">
                  <span>Experience:</span>
                  <span>${staff.experience} years</span>
                </div>
              </div>
              <div class="d-flex justify-content-center gap-2">
                <button class="btn btn-sm btn-primary edit-staff" data-id="${
                  staff.id
                }">
                  <i class="fas fa-edit me-1"></i> Edit
                </button>
                <button class="btn btn-sm btn-outline-danger delete-staff" data-id="${
                  staff.id
                }">
                  <i class="fas fa-trash me-1"></i> Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    });

    staffCardsContainer.html(staffCardsHtml);

    // Setup edit and delete buttons
    $(".edit-staff").on("click", function () {
      const staffId = $(this).data("id");
      // In a real application, you would open a modal with the staff details
      alert(`Edit staff ${staffId}`);
    });

    $(".delete-staff").on("click", function () {
      const staffId = $(this).data("id");
      // In a real application, you would show a confirmation modal
      alert(`Delete staff ${staffId}`);
    });
  }
}

// Initialize Customers Tab
function initializeCustomersTab() {
  const customersTableContainer = $("#customers-table");

  if (customersTableContainer.length) {
    renderCustomersTable(customersData);

    // Handle sorting and searching
    $("#customer-sort").on("change", function () {
      sortCustomers(customersData, $(this).val());
    });

    $("#customer-search").on("input", function () {
      filterCustomers();
    });

    // Update counts
    updateCustomerCounts();

    // Handle export button
    $("#export-customers").on("click", function () {
      // In a real application, you would generate a CSV or Excel file
      alert(
        "In a real application, this would export the customer data to a CSV or Excel file."
      );
    });
  }
}

// Render Customers Table
function renderCustomersTable(customers) {
  const customersTableContainer = $("#customers-table");

  if (customersTableContainer.length && customers.length > 0) {
    let customersHtml = "";

    customers.forEach((customer) => {
      customersHtml += `
        <tr data-id="${customer.id}">
          <td>
            <div>
              <span class="fw-medium">${customer.name}</span>
              <small class="d-block text-muted">${customer.gender}</small>
            </div>
          </td>
          <td>
            <div>
              <span>${customer.phone}</span>
              <small class="d-block text-muted">${customer.email}</small>
            </div>
          </td>
          <td>${formatDate(customer.lastVisit)}</td>
          <td>${customer.totalVisits}</td>
          <td>₹${customer.totalSpent}</td>
          <td>
            <div class="btn-group">
              <button class="btn btn-sm btn-outline-primary view-customer" data-id="${
                customer.id
              }">
                <i class="fas fa-eye"></i>
              </button>
              <button class="btn btn-sm btn-outline-primary edit-customer" data-id="${
                customer.id
              }">
                <i class="fas fa-edit"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger delete-customer" data-id="${
                customer.id
              }">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    });

    customersTableContainer.html(customersHtml);

    // Setup view, edit, and delete buttons
    $(".view-customer").on("click", function () {
      const customerId = $(this).data("id");
      // In a real application, you would open a modal with the customer details
      alert(`View customer ${customerId}`);
    });

    $(".edit-customer").on("click", function () {
      const customerId = $(this).data("id");
      // In a real application, you would open a modal with the customer details
      alert(`Edit customer ${customerId}`);
    });

    $(".delete-customer").on("click", function () {
      const customerId = $(this).data("id");
      // In a real application, you would show a confirmation modal
      alert(`Delete customer ${customerId}`);
    });
  } else {
    customersTableContainer.html(
      '<tr><td colspan="6" class="text-center">No customers found</td></tr>'
    );
  }
}

// Sort Customers
function sortCustomers(customers, sortBy) {
  let sortedCustomers = [...customers];

  switch (sortBy) {
    case "name":
      sortedCustomers.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case "visits":
      sortedCustomers.sort((a, b) => b.totalVisits - a.totalVisits);
      break;
    case "recent":
    default:
      sortedCustomers.sort((a, b) => b.lastVisit.localeCompare(a.lastVisit));
      break;
  }

  renderCustomersTable(sortedCustomers);
}

// Filter Customers
function filterCustomers() {
  const searchTerm = $("#customer-search").val().toLowerCase();
  const sortBy = $("#customer-sort").val();

  let filteredCustomers = [...customersData];

  // Apply search
  if (searchTerm) {
    filteredCustomers = filteredCustomers.filter(
      (customer) =>
        customer.name.toLowerCase().includes(searchTerm) ||
        customer.email.toLowerCase().includes(searchTerm) ||
        customer.phone.includes(searchTerm)
    );
  }

  // Apply sorting
  sortCustomers(filteredCustomers, sortBy);

  // Update counts
  updateCustomerCounts(filteredCustomers.length);
}

// Update Customer Counts
function updateCustomerCounts(filteredCount) {
  const totalCount = customersData.length;
  $("#total-customers-count").text(totalCount);
  $("#shown-customers").text(
    filteredCount !== undefined ? filteredCount : totalCount
  );
}

// Initialize Inventory Tab
function initializeInventoryTab() {
  const inventoryTableContainer = $("#inventory-table");

  if (inventoryTableContainer.length) {
    renderInventoryTable(inventoryData);

    // Handle filters and sorting
    $(
      "#inventory-category-filter, #inventory-stock-filter, #inventory-sort"
    ).on("change", function () {
      filterAndSortInventory();
    });

    // Handle search
    $("#inventory-search").on("input", function () {
      filterAndSortInventory();
    });
  }
}

// Render Inventory Table
function renderInventoryTable(inventory) {
  const inventoryTableContainer = $("#inventory-table");

  if (inventoryTableContainer.length && inventory.length > 0) {
    let inventoryHtml = "";

    inventory.forEach((item) => {
      const statusClass = getInventoryStatusClass(item.status);

      inventoryHtml += `
        <tr data-id="${item.id}">
          <td>
            <div>
              <span class="fw-medium">${item.name}</span>
              <small class="d-block text-muted">${item.brand}</small>
            </div>
          </td>
          <td>${formatCategory(item.category)}</td>
          <td>
            <div>
              <span class="fw-medium">${item.stock}</span>
              <small class="d-block text-muted">Min: ${item.minStock}</small>
            </div>
          </td>
          <td>₹${item.sellingPrice}</td>
          <td><span class="status-badge ${statusClass}">${formatInventoryStatus(
        item.status
      )}</span></td>
          <td>
            <div class="btn-group">
              <button class="btn btn-sm btn-outline-primary edit-inventory" data-id="${
                item.id
              }">
                <i class="fas fa-edit"></i>
              </button>
              <button class="btn btn-sm btn-outline-success update-stock" data-id="${
                item.id
              }">
                <i class="fas fa-sync-alt"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger delete-inventory" data-id="${
                item.id
              }">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    });

    inventoryTableContainer.html(inventoryHtml);

    // Setup buttons
    $(".edit-inventory").on("click", function () {
      const itemId = $(this).data("id");
      // In a real application, you would open a modal with the inventory item details
      alert(`Edit inventory item ${itemId}`);
    });

    $(".update-stock").on("click", function () {
      const itemId = $(this).data("id");
      // In a real application, you would open a modal to update the stock
      alert(`Update stock for item ${itemId}`);
    });

    $(".delete-inventory").on("click", function () {
      const itemId = $(this).data("id");
      // In a real application, you would show a confirmation modal
      alert(`Delete inventory item ${itemId}`);
    });
  } else {
    inventoryTableContainer.html(
      '<tr><td colspan="6" class="text-center">No inventory items found</td></tr>'
    );
  }
}

// Filter and Sort Inventory
function filterAndSortInventory() {
  const categoryFilter = $("#inventory-category-filter").val();
  const stockFilter = $("#inventory-stock-filter").val();
  const sortBy = $("#inventory-sort").val();
  const searchTerm = $("#inventory-search").val().toLowerCase();

  let filteredInventory = [...inventoryData];

  // Apply category filter
  if (categoryFilter) {
    filteredInventory = filteredInventory.filter(
      (item) => item.category === categoryFilter
    );
  }

  // Apply stock filter
  if (stockFilter) {
    filteredInventory = filteredInventory.filter(
      (item) => item.status === stockFilter
    );
  }

  // Apply search
  if (searchTerm) {
    filteredInventory = filteredInventory.filter(
      (item) =>
        item.name.toLowerCase().includes(searchTerm) ||
        item.brand.toLowerCase().includes(searchTerm)
    );
  }

  // Apply sorting
  switch (sortBy) {
    case "name":
      filteredInventory.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case "stock-low":
      filteredInventory.sort((a, b) => a.stock - b.stock);
      break;
    case "stock-high":
      filteredInventory.sort((a, b) => b.stock - a.stock);
      break;
    case "price-low":
      filteredInventory.sort((a, b) => a.sellingPrice - b.sellingPrice);
      break;
    case "price-high":
      filteredInventory.sort((a, b) => b.sellingPrice - a.sellingPrice);
      break;
  }

  renderInventoryTable(filteredInventory);
}

// Setup Form Submissions
function setupFormSubmissions() {
  // Salon Information Form
  $("#salon-info-form").on("submit", function (event) {
    event.preventDefault();
    alert("Salon information updated successfully!");
  });

  // Business Hours Form
  $("#business-hours-form").on("submit", function (event) {
    event.preventDefault();
    alert("Business hours updated successfully!");
  });

  // Notification Settings Form
  $("#notification-settings-form").on("submit", function (event) {
    event.preventDefault();
    alert("Notification settings updated successfully!");
  });

  // Add Appointment Form
  $("#save-appointment-btn").on("click", function () {
    // In a real application, you would validate the form and save the data
    alert("Appointment added successfully!");
    $("#addAppointmentModal").modal("hide");
  });

  // Add Service Form
  $("#save-service-btn").on("click", function () {
    // In a real application, you would validate the form and save the data
    alert("Service added successfully!");
    $("#addServiceModal").modal("hide");
  });

  // Add Staff Form
  $("#save-staff-btn").on("click", function () {
    // In a real application, you would validate the form and save the data
    alert("Staff added successfully!");
    $("#addStaffModal").modal("hide");
  });

  // Add Customer Form
  $("#save-customer-btn").on("click", function () {
    // In a real application, you would validate the form and save the data
    alert("Customer added successfully!");
    $("#addCustomerModal").modal("hide");
  });

  // Add Inventory Form
  $("#save-inventory-btn").on("click", function () {
    // In a real application, you would validate the form and save the data
    alert("Inventory item added successfully!");
    $("#addInventoryModal").modal("hide");
  });
}

// ===== Utility Functions =====

// Format date: YYYY-MM-DD to DD Month YYYY
function formatDate(dateString) {
  const options = { year: "numeric", month: "short", day: "numeric" };
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", options);
}

// Get status badge class based on status
function getStatusClass(status) {
  switch (status) {
    case "confirmed":
      return "status-confirmed";
    case "pending":
      return "status-pending";
    case "completed":
      return "status-completed";
    case "cancelled":
      return "status-cancelled";
    default:
      return "";
  }
}

// Get inventory status badge class
function getInventoryStatusClass(status) {
  switch (status) {
    case "in-stock":
      return "status-confirmed";
    case "low-stock":
      return "status-pending";
    case "out-of-stock":
      return "status-cancelled";
    default:
      return "";
  }
}

// Format inventory status
function formatInventoryStatus(status) {
  switch (status) {
    case "in-stock":
      return "In Stock";
    case "low-stock":
      return "Low Stock";
    case "out-of-stock":
      return "Out of Stock";
    default:
      return status;
  }
}

// Format category
function formatCategory(category) {
  return category
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

// Capitalize first letter
function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
