// Booking Page JavaScript for Jawed Habib Hair & Beauty

// Global variables to store booking data
let selectedServices = [];
let selectedStaff = null;
let selectedDate = null;
let selectedTime = null;
let customerData = {};

// ===== DOM Ready =====
$(document).ready(function () {
  // Initialize today's date as the minimum selectable date
  const today = new Date();
  const formattedDate = today.toISOString().split("T")[0];
  $("#appointment-date").attr("min", formattedDate);

  // Load service categories in the booking form
  loadBookingServices();

  // Load staff members for selection
  loadStaffSelection();

  // Set up navigation between booking steps
  setupBookingNavigation();

  // Set up service selection functionality
  setupServiceSelection();

  // Set up date and time selection
  setupDateTimeSelection();

  // Set up form validation
  setupFormValidation();

  // Handle booking confirmation
  setupBookingConfirmation();
});

// ===== Functions =====

// Load Service Categories in the booking form
function loadBookingServices() {
  const serviceCategoriesContainer = $("#service-categories-list");

  if (serviceCategoriesContainer.length) {
    serviceCategoriesContainer.empty();

    let categoriesHtml = "";
    serviceCategories.forEach((categoryData) => {
      categoriesHtml += `
        <div class="service-category-section mb-4">
          <h4 class="fs-6 fw-semibold mb-3">${categoryData.category}</h4>
          <div class="row g-3">
            ${categoryData.services
              .map(
                (service) => `
              <div class="col-md-6">
                <div class="card service-selection-card h-100">
                  <div class="card-body">
                    <div class="form-check">
                      <input class="form-check-input service-checkbox" type="checkbox" value="${service.id}" id="service-${service.id}" data-name="${service.name}" data-price="${service.price}" data-duration="${service.duration}">
                      <label class="form-check-label w-100" for="service-${service.id}">
                        <div class="d-flex justify-content-between align-items-start">
                          <div>
                            <p class="fw-medium mb-0">${service.name}</p>
                            <small class="text-muted d-block">${service.duration} min</small>
                            <small class="service-description text-muted d-block">${service.description}</small>
                          </div>
                          <span class="service-price">₹${service.price}</span>
                        </div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            `
              )
              .join("")}
          </div>
        </div>
      `;
    });

    serviceCategoriesContainer.html(categoriesHtml);

    // Setup service search functionality
    setupServiceSearch();
  }
}

// Set up service search functionality
function setupServiceSearch() {
  $("#service-search").on("input", function () {
    const searchTerm = $(this).val().toLowerCase().trim();

    if (searchTerm === "") {
      $(".service-category-section").show();
      $(".service-selection-card").show();
      return;
    }

    $(".service-category-section").each(function () {
      const categorySection = $(this);
      const categoryTitle = categorySection.find("h4").text().toLowerCase();
      let hasVisibleServices = false;

      categorySection.find(".service-selection-card").each(function () {
        const serviceCard = $(this);
        const serviceName = serviceCard.find("label p").text().toLowerCase();
        const serviceDescription = serviceCard
          .find(".service-description")
          .text()
          .toLowerCase();

        if (
          serviceName.includes(searchTerm) ||
          serviceDescription.includes(searchTerm) ||
          categoryTitle.includes(searchTerm)
        ) {
          serviceCard.show();
          hasVisibleServices = true;
        } else {
          serviceCard.hide();
        }
      });

      if (hasVisibleServices) {
        categorySection.show();
      } else {
        categorySection.hide();
      }
    });
  });
}

// Load Staff Members for selection
function loadStaffSelection() {
  const staffSelect = $("#staff-select");

  if (staffSelect.length) {
    staffMembers.forEach((staff) => {
      staffSelect.append(
        `<option value="${staff.id}">${staff.name} - ${staff.role}</option>`
      );
    });
  }
}

// Set up navigation between booking steps
function setupBookingNavigation() {
  // Step 1 to Step 2
  $("#step-1-next").on("click", function () {
    if (selectedServices.length === 0) {
      alert("Please select at least one service to continue.");
      return;
    }

    // Hide Step 1, show Step 2
    $("#booking-step-1").addClass("d-none");
    $("#booking-step-2").removeClass("d-none");

    // Update navigation
    $("#step-nav-1").removeClass("active");
    $("#step-nav-2").addClass("active");
  });

  // Step 2 to Step 1 (back)
  $("#step-2-prev").on("click", function () {
    // Hide Step 2, show Step 1
    $("#booking-step-2").addClass("d-none");
    $("#booking-step-1").removeClass("d-none");

    // Update navigation
    $("#step-nav-2").removeClass("active");
    $("#step-nav-1").addClass("active");
  });

  // Step 2 to Step 3
  $("#step-2-next").on("click", function () {
    if (!selectedStaff) {
      alert("Please select a stylist.");
      return;
    }

    if (!selectedDate) {
      alert("Please select a date.");
      return;
    }

    if (!selectedTime) {
      alert("Please select a time slot.");
      return;
    }

    // Hide Step 2, show Step 3
    $("#booking-step-2").addClass("d-none");
    $("#booking-step-3").removeClass("d-none");

    // Update navigation
    $("#step-nav-2").removeClass("active");
    $("#step-nav-3").addClass("active");
  });

  // Step 3 to Step 2 (back)
  $("#step-3-prev").on("click", function () {
    // Hide Step 3, show Step 2
    $("#booking-step-3").addClass("d-none");
    $("#booking-step-2").removeClass("d-none");

    // Update navigation
    $("#step-nav-3").removeClass("active");
    $("#step-nav-2").addClass("active");
  });

  // Step 3 to Step 4
  $("#step-3-next").on("click", function () {
    if (!validateCustomerForm()) {
      return;
    }

    // Collect customer data
    customerData = {
      name: $("#customer-name").val(),
      phone: $("#customer-phone").val(),
      email: $("#customer-email").val() || "Not provided",
      gender: $("#customer-gender").val(),
      notes: $("#customer-notes").val() || "No special requests",
    };

    // Update booking summary
    updateBookingSummary();

    // Hide Step 3, show Step 4
    $("#booking-step-3").addClass("d-none");
    $("#booking-step-4").removeClass("d-none");

    // Update navigation
    $("#step-nav-3").removeClass("active");
    $("#step-nav-4").addClass("active");
  });

  // Step 4 to Step 3 (back)
  $("#step-4-prev").on("click", function () {
    // Hide Step 4, show Step 3
    $("#booking-step-4").addClass("d-none");
    $("#booking-step-3").removeClass("d-none");

    // Update navigation
    $("#step-nav-4").removeClass("active");
    $("#step-nav-3").addClass("active");
  });
}

// Set up service selection functionality
function setupServiceSelection() {
  // Handle service selection
  $(document).on("change", ".service-checkbox", function () {
    const serviceId = parseInt($(this).val());
    const serviceName = $(this).data("name");
    const servicePrice = $(this).data("price");
    const serviceDuration = $(this).data("duration");

    if ($(this).is(":checked")) {
      // Add service to selected services
      selectedServices.push({
        id: serviceId,
        name: serviceName,
        price: servicePrice,
        duration: serviceDuration,
      });
    } else {
      // Remove service from selected services
      selectedServices = selectedServices.filter(
        (service) => service.id !== serviceId
      );
    }

    // Update selected services display
    updateSelectedServices();
  });
}

// Update selected services display
function updateSelectedServices() {
  const selectedServicesContainer = $("#selected-services-list");
  const noServicesMessage = $("#no-services-selected");

  if (selectedServices.length === 0) {
    selectedServicesContainer.addClass("d-none");
    noServicesMessage.removeClass("d-none");
    return;
  }

  selectedServicesContainer.removeClass("d-none");
  noServicesMessage.addClass("d-none");

  // Calculate total price and duration
  const totalPrice = selectedServices.reduce(
    (sum, service) => sum + service.price,
    0
  );
  const totalDuration = selectedServices.reduce(
    (sum, service) => sum + service.duration,
    0
  );

  let servicesHtml = '<ul class="list-group mb-3">';
  selectedServices.forEach((service) => {
    servicesHtml += `
      <li class="list-group-item d-flex justify-content-between align-items-center">
        <div>
          <span class="fw-medium">${service.name}</span>
          <small class="d-block text-muted">${service.duration} min</small>
        </div>
        <div class="d-flex align-items-center">
          <span class="service-price me-3">₹${service.price}</span>
          <button class="btn btn-sm btn-outline-danger remove-service" data-id="${service.id}">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </li>
    `;
  });
  servicesHtml += "</ul>";

  servicesHtml += `
    <div class="d-flex justify-content-between align-items-center p-3 bg-light rounded">
      <div>
        <span class="fw-medium">Total</span>
        <small class="d-block text-muted">Appointment Duration: ${totalDuration} min</small>
      </div>
      <span class="fs-5 fw-semibold">₹${totalPrice}</span>
    </div>
  `;

  selectedServicesContainer.html(servicesHtml);

  // Handle remove service buttons
  $(".remove-service").on("click", function () {
    const serviceId = parseInt($(this).data("id"));

    // Uncheck the corresponding checkbox
    $(`#service-${serviceId}`).prop("checked", false);

    // Remove from selected services
    selectedServices = selectedServices.filter(
      (service) => service.id !== serviceId
    );

    // Update display
    updateSelectedServices();
  });
}

// Set up date and time selection
function setupDateTimeSelection() {
  // Handle date selection
  $("#appointment-date").on("change", function () {
    selectedDate = $(this).val();

    // Reset time selection if staff is already selected
    if (selectedStaff) {
      generateTimeSlots();
    }
  });

  // Handle staff selection
  $("#staff-select").on("change", function () {
    selectedStaff = $(this).val();

    // Reset time selection if date is already selected
    if (selectedDate) {
      generateTimeSlots();
    }
  });
}

// Generate time slots based on selected date and staff
function generateTimeSlots() {
  const timeSlotsContainer = $("#time-slots");

  if (!selectedDate || !selectedStaff) {
    timeSlotsContainer.html(`
      <div class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i> Please select a date and stylist to view available time slots.
      </div>
    `);
    return;
  }

  // In a real application, available time slots would be fetched from a server
  // For this example, we'll generate time slots between 10 AM and 6 PM
  const startHour = 10;
  const endHour = 18;
  const slotDuration = 30; // minutes
  const slots = [];

  // Generate slots
  for (let hour = startHour; hour < endHour; hour++) {
    for (let minute = 0; minute < 60; minute += slotDuration) {
      const timeString = `${hour.toString().padStart(2, "0")}:${minute
        .toString()
        .padStart(2, "0")}`;

      // Randomly determine if a slot is available (for demonstration purposes)
      const isAvailable = Math.random() > 0.3;

      slots.push({
        time: timeString,
        available: isAvailable,
      });
    }
  }

  // Generate HTML for time slots
  let timeSlotsHtml = '<div class="time-slots-container">';
  slots.forEach((slot) => {
    const timeClass = slot.available ? "time-slot" : "time-slot unavailable";
    const disabled = slot.available ? "" : "disabled";

    timeSlotsHtml += `
      <button class="${timeClass}" ${disabled} data-time="${slot.time}">
        ${slot.time}
      </button>
    `;
  });
  timeSlotsHtml += "</div>";

  timeSlotsContainer.html(timeSlotsHtml);

  // Handle time slot selection
  $(".time-slot:not(.unavailable)").on("click", function () {
    $(".time-slot").removeClass("selected");
    $(this).addClass("selected");
    selectedTime = $(this).data("time");
  });
}

// Set up form validation
function setupFormValidation() {
  // For now, we'll use simple validation
  // In a real application, you might want to use a validation library
}

// Validate customer form
function validateCustomerForm() {
  const name = $("#customer-name").val();
  const phone = $("#customer-phone").val();

  if (!name || !phone) {
    alert("Please fill in all required fields.");
    return false;
  }

  // Basic phone number validation
  const phoneRegex = /^\d{10}$/;
  if (!phoneRegex.test(phone)) {
    alert("Please enter a valid 10-digit phone number.");
    return false;
  }

  return true;
}

// Update booking summary
function updateBookingSummary() {
  // Customer info
  $("#summary-customer").text(customerData.name);

  // Services
  let servicesHtml = '<ul class="mb-0 ps-0" style="list-style-type: none;">';
  let totalPrice = 0;

  selectedServices.forEach((service) => {
    servicesHtml += `<li>${service.name} - ₹${service.price}</li>`;
    totalPrice += service.price;
  });

  servicesHtml += "</ul>";
  $("#summary-services").html(servicesHtml);

  // Stylist
  const staffName = $(`#staff-select option[value="${selectedStaff}"]`).text();
  $("#summary-stylist").text(staffName);

  // Date and time
  const formattedDate = new Date(selectedDate).toLocaleDateString("en-IN", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  $("#summary-datetime").text(`${formattedDate} at ${selectedTime}`);

  // Total price
  $("#summary-price").text(`₹${totalPrice}`);
}

// Handle booking confirmation
function setupBookingConfirmation() {
  $("#confirm-booking-btn").on("click", function () {
    if (!$("#terms-checkbox").is(":checked")) {
      alert(
        "Please agree to the terms and conditions to complete your booking."
      );
      return;
    }

    // In a real application, you would send the booking data to a server
    // For this example, we'll just simulate a successful booking

    // Generate a random booking reference
    const bookingRef = "JH" + Math.floor(100000 + Math.random() * 900000);
    $("#booking-reference").text(bookingRef);

    // Generate confirmation details
    let confirmationHtml = `
      <div class="confirmation-item d-flex mb-3">
        <i class="fas fa-user text-primary mt-1"></i>
        <div class="ms-3">
          <p class="fw-semibold mb-0">Customer:</p>
          <p class="mb-0">${customerData.name}</p>
          <p class="mb-0">${customerData.phone}</p>
          <p class="mb-0">${customerData.email}</p>
        </div>
      </div>
      
      <div class="confirmation-item d-flex mb-3">
        <i class="fas fa-calendar text-primary mt-1"></i>
        <div class="ms-3">
          <p class="fw-semibold mb-0">Appointment:</p>
          <p class="mb-0">${new Date(selectedDate).toLocaleDateString("en-IN", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          })}</p>
          <p class="mb-0">Time: ${selectedTime}</p>
        </div>
      </div>
      
      <div class="confirmation-item d-flex mb-3">
        <i class="fas fa-cut text-primary mt-1"></i>
        <div class="ms-3">
          <p class="fw-semibold mb-0">Services:</p>
          <ul class="mb-0 ps-3">
            ${selectedServices
              .map((service) => `<li>${service.name} - ₹${service.price}</li>`)
              .join("")}
          </ul>
        </div>
      </div>
      
      <div class="confirmation-item d-flex">
        <i class="fas fa-user-tie text-primary mt-1"></i>
        <div class="ms-3">
          <p class="fw-semibold mb-0">Stylist:</p>
          <p class="mb-0">${$(
            `#staff-select option[value="${selectedStaff}"]`
          ).text()}</p>
        </div>
      </div>
    `;

    $("#confirmation-details").html(confirmationHtml);

    // Show success step
    $("#booking-step-4").addClass("d-none");
    $("#booking-success").removeClass("d-none");
  });

  // Handle download confirmation
  $("#download-confirm-btn").on("click", function () {
    alert(
      "In a real application, this would generate a PDF confirmation that you could download or send via email."
    );
  });
}
