// Main JavaScript file for Jawed Habib Hair & Beauty Website

// ===== Data Storage =====
// These would normally be fetched from an API, but for this static example, we'll define them here

// Service Categories and Services
const serviceCategories = [
  {
    category: "Haircut & Styling",
    services: [
      {
        id: 1,
        name: "Women's Haircut",
        description:
          "Professional haircut service including consultation, shampoo, and style.",
        duration: 60,
        price: 600,
      },
      {
        id: 2,
        name: "Men's Haircut",
        description:
          "Precision haircut service for men including consultation and styling.",
        duration: 45,
        price: 450,
      },
      {
        id: 3,
        name: "Kids Haircut",
        description: "Gentle and fun haircut experience for children under 12.",
        duration: 30,
        price: 300,
      },
      {
        id: 4,
        name: "Blowout & Styling",
        description:
          "Professional blow dry and styling service for any occasion.",
        duration: 45,
        price: 500,
      },
    ],
  },
  {
    category: "Hair Coloring",
    services: [
      {
        id: 5,
        name: "Root Touch-up",
        description:
          "Color application to the roots to cover grey or regrowth.",
        duration: 60,
        price: 1200,
      },
      {
        id: 6,
        name: "Full Color",
        description:
          "All-over hair color application for a complete color change or refresh.",
        duration: 90,
        price: 2000,
      },
      {
        id: 7,
        name: "Highlights/Lowlights",
        description:
          "Dimensional color technique to add depth and dimension to hair.",
        duration: 120,
        price: 2500,
      },
      {
        id: 8,
        name: "Balayage/Ombre",
        description:
          "Hand-painted highlighting technique for a natural, sun-kissed look.",
        duration: 180,
        price: 3500,
      },
    ],
  },
  {
    category: "Hair Treatments",
    services: [
      {
        id: 9,
        name: "Deep Conditioning Treatment",
        description:
          "Intensive conditioning to restore moisture and shine to dry, damaged hair.",
        duration: 30,
        price: 800,
      },
      {
        id: 10,
        name: "Scalp Treatment",
        description:
          "Therapeutic treatment to address scalp issues and promote healthy hair growth.",
        duration: 45,
        price: 1000,
      },
      {
        id: 11,
        name: "Keratin Smoothing Treatment",
        description:
          "Smoothing treatment to reduce frizz and add shine for up to 3 months.",
        duration: 120,
        price: 4500,
      },
      {
        id: 12,
        name: "Hair Spa",
        description:
          "Luxurious spa treatment for hair including massage and steam therapy.",
        duration: 60,
        price: 1500,
      },
    ],
  },
  {
    category: "Beauty Services",
    services: [
      {
        id: 13,
        name: "Eyebrow Threading",
        description: "Precise eyebrow shaping using the threading technique.",
        duration: 15,
        price: 150,
      },
      {
        id: 14,
        name: "Facial",
        description:
          "Customized facial treatment to cleanse, exfoliate, and nourish the skin.",
        duration: 60,
        price: 1800,
      },
      {
        id: 15,
        name: "Manicure",
        description:
          "Classic manicure service including nail shaping, cuticle care, and polish.",
        duration: 45,
        price: 500,
      },
      {
        id: 16,
        name: "Pedicure",
        description:
          "Relaxing pedicure service including foot soak, exfoliation, and polish.",
        duration: 60,
        price: 700,
      },
    ],
  },
];

// Staff Members
const staffMembers = [
  {
    id: 1,
    name: "Priya Sharma",
    role: "Senior Hair Stylist",
    image: "https://images.unsplash.com/photo-1580618672591-eb180b1a973f",
    bio: "With over 8 years of experience, Priya specializes in precision cuts and creative coloring techniques.",
    specialties: ["Precision Cuts", "Creative Color", "Balayage"],
    experience: 8,
  },
  {
    id: 2,
    name: "Raj Patel",
    role: "Master Stylist",
    image: "https://images.unsplash.com/photo-1583195764036-6dc248ac07d9",
    bio: "Raj is our master stylist with 12 years of experience and international training in the latest hair trends.",
    specialties: ["Avant-garde Styling", "Color Correction", "Extensions"],
    experience: 12,
  },
  {
    id: 3,
    name: "Ananya Singh",
    role: "Color Specialist",
    image: "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604",
    bio: "Ananya is our color expert with advanced training in the latest techniques to achieve the perfect shade for every client.",
    specialties: ["Balayage", "Fashion Colors", "Highlighting"],
    experience: 6,
  },
  {
    id: 4,
    name: "Vikram Malhotra",
    role: "Stylist & Barber",
    image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857",
    bio: "Specializing in both men's and women's styles, Vikram is known for his versatility and attention to detail.",
    specialties: ["Men's Cuts", "Beard Grooming", "Classic Styling"],
    experience: 5,
  },
  {
    id: 5,
    name: "Neha Verma",
    role: "Beauty Therapist",
    image: "https://images.unsplash.com/photo-1548142813-c348350df52b",
    bio: "Neha is our beauty expert providing exceptional skincare and makeup services for all occasions.",
    specialties: ["Facials", "Makeup", "Threading"],
    experience: 7,
  },
  {
    id: 6,
    name: "Arjun Kapoor",
    role: "Junior Stylist",
    image: "https://images.unsplash.com/photo-1563351672-62b74891a28a",
    bio: "With fresh ideas and techniques, Arjun brings a modern perspective to our salon team.",
    specialties: ["Modern Cuts", "Styling", "Client Consultation"],
    experience: 2,
  },
];

// ===== DOM Ready =====
$(document).ready(function () {
  // Load services on homepage
  loadServiceCategories();

  // Load staff on homepage
  loadStaffMembers();

  // Smooth scrolling for navigation links
  implementSmoothScrolling();

  // Contact form submission
  setupContactForm();
});

// ===== Functions =====

// Load Service Categories on the homepage
function loadServiceCategories() {
  const serviceCategoriesContainer = $("#service-categories");

  if (serviceCategoriesContainer.length) {
    serviceCategoriesContainer.empty();

    serviceCategories.forEach((categoryData) => {
      const categoryHtml = `
        <div class="col-md-6 col-lg-3 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body">
              <h3 class="fs-5 fw-semibold mb-3">${categoryData.category}</h3>
              <ul class="list-unstyled">
                ${categoryData.services
                  .map(
                    (service) => `
                  <li class="mb-3">
                    <div class="d-flex justify-content-between align-items-start">
                      <div>
                        <p class="fw-medium mb-0">${service.name}</p>
                        <small class="text-muted">${service.duration} min</small>
                      </div>
                      <span class="service-price">₹${service.price}</span>
                    </div>
                  </li>
                `
                  )
                  .join("")}
              </ul>
              <a href="booking.html" class="btn btn-outline-primary w-100">Book Now</a>
            </div>
          </div>
        </div>
      `;

      serviceCategoriesContainer.append(categoryHtml);
    });
  }

  // Load services in the quick booking section if it exists
  const servicesListContainer = $("#services-list");
  if (servicesListContainer.length) {
    servicesListContainer.empty();

    let servicesList = "";
    serviceCategories.forEach((categoryData) => {
      servicesList += `
        <div class="service-category-section mb-4">
          <h4 class="fs-6 fw-semibold mb-3">${categoryData.category}</h4>
          <div class="row g-3">
            ${categoryData.services
              .map(
                (service) => `
              <div class="col-md-6">
                <div class="card service-selection-card h-100">
                  <div class="card-body">
                    <div class="form-check">
                      <input class="form-check-input service-checkbox" type="checkbox" value="${service.id}" id="service-${service.id}">
                      <label class="form-check-label w-100" for="service-${service.id}">
                        <div class="d-flex justify-content-between align-items-start">
                          <div>
                            <p class="fw-medium mb-0">${service.name}</p>
                            <small class="text-muted d-block">${service.duration} min</small>
                            <small class="service-description text-muted d-block">${service.description}</small>
                          </div>
                          <span class="service-price">₹${service.price}</span>
                        </div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            `
              )
              .join("")}
          </div>
        </div>
      `;
    });

    servicesListContainer.html(servicesList);
  }
}

// Load Staff Members on the homepage
function loadStaffMembers() {
  const staffContainer = $("#staff-list");

  if (staffContainer.length) {
    staffContainer.empty();

    staffMembers.forEach((staff) => {
      const staffHtml = `
        <div class="col-md-6 col-lg-4">
          <div class="card staff-card shadow-sm p-4 text-center h-100">
            <img src="${staff.image}" alt="${
        staff.name
      }" class="staff-image mx-auto">
            <h3 class="fs-5 fw-semibold mt-3 mb-1">${staff.name}</h3>
            <p class="staff-role mb-3">${staff.role}</p>
            <p class="staff-bio mb-3">${staff.bio}</p>
            <div class="staff-specialties">
              <small class="d-block mb-2 fw-semibold">Specialties:</small>
              <div>
                ${staff.specialties
                  .map(
                    (specialty) => `
                  <span class="badge bg-light text-dark me-1 mb-1">${specialty}</span>
                `
                  )
                  .join("")}
              </div>
            </div>
          </div>
        </div>
      `;

      staffContainer.append(staffHtml);
    });
  }
}

// Implement Smooth Scrolling for Navigation Links
function implementSmoothScrolling() {
  $('a[href*="#"]:not([href="#"])').on("click", function (event) {
    if (
      location.pathname.replace(/^\//, "") ==
        this.pathname.replace(/^\//, "") &&
      location.hostname == this.hostname
    ) {
      let target = $(this.hash);
      target = target.length ? target : $("[name=" + this.hash.slice(1) + "]");

      if (target.length) {
        event.preventDefault();
        $("html, body").animate(
          {
            scrollTop: target.offset().top - 80,
          },
          800
        );
        return false;
      }
    }
  });
}

// Contact Form Setup
function setupContactForm() {
  $("#contact-form").on("submit", function (event) {
    event.preventDefault();

    const name = $("#name").val();
    const email = $("#email").val();
    const phone = $("#phone").val();
    const message = $("#message").val();

    if (!name || !email || !phone || !message) {
      alert("Please fill all the required fields.");
      return;
    }

    // In a real application, you would send this data to a server
    // For now, we'll just show a success message
    alert("Thank you for your message! We will get back to you soon.");
    this.reset();
  });
}
